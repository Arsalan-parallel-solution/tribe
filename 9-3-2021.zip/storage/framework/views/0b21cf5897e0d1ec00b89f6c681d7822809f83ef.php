
<?php $__env->startSection('content'); ?>
 <?php echo $data['body']; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email_company_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\NewsManagement\example-app\resources\views/emails/site/company_panel.blade.php ENDPATH**/ ?>