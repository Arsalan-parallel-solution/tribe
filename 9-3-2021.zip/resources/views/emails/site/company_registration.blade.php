@extends('layouts.email_template')
@section('content')
 {!! $data['body'] !!}
@endsection