<div style="margin:0!important;padding:0;background-color:#f0f7f7" bgcolor="#f0f7f7">
	<br/>
	<br/>
	<table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
		<tbody>
			<tr>
				<td style="padding:0 15px 50px 15px" class="m_-6768696684458228336mobile-padding" width="100%" valign="top" height="100%" bgcolor="#f0f7f7" align="center">
					
				</td>
			</tr>
		</tbody>
	</table>
	<table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
		<tbody>
			<tr>
				<td style="padding:0 15px 50px 15px" class="m_-6768696684458228336mobile-padding" width="100%" valign="top" height="100%" bgcolor="#f0f7f7" align="center">
					<table style="max-width:600px;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
						<tbody>
							<tr>
								<td style="padding:0 0 25px 0;font-family:Open Sans,Helvetica,Arial,sans-serif" valign="top" align="center">
									<table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="border-top-left-radius:10px;border-top-right-radius:10px;padding:55px;padding-bottom:1px" bgcolor="#ffffff" align="center">
													<table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
												                <td colspan="2" style="font-family:Open Sans,Helvetica,Arial,sans-serif" align="left">
																	<?php echo $__env->yieldContent('content'); ?>
																</td>
															</tr>	
														</tbody>
													</table>
												</td>
											</tr>
											
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</div><?php /**PATH D:\NewsManagement\example-app\resources\views/layouts/email_company_template.blade.php ENDPATH**/ ?>